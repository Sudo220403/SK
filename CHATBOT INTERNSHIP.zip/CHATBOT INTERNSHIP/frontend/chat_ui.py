import gradio as gr
import requests

def upload_file(file):
    files = {'file': (file.name, file)}
    res = requests.post("http://127.0.0.1:8000/upload/", files=files)
    return res.json()

def ask_question(question):
    res = requests.post("http://127.0.0.1:8000/ask/", data={"question": question})
    return res.json().get("response", "No answer found.")

def extract_themes(question):
    res = requests.post("http://127.0.0.1:8000/themes/", data={"question": question})
    return res.json().get("themes", "No themes identified.")

with gr.Blocks() as demo:
    gr.Markdown("## Document Chatbot")
    file = gr.File(label="Upload a PDF/Image")
    upload_btn = gr.Button("Upload Document")
    upload_output = gr.Textbox(label="Upload Result")

    question_input = gr.Textbox(label="Ask a Question")
    ask_btn = gr.Button("Get Answer")
    answer_output = gr.Textbox(label="Answer")

    theme_input = gr.Textbox(label="Extract Themes From Question")
    theme_btn = gr.Button("Identify Themes")
    theme_output = gr.Textbox(label="Themes")

    upload_btn.click(upload_file, inputs=file, outputs=upload_output)
    ask_btn.click(ask_question, inputs=question_input, outputs=answer_output)
    theme_btn.click(extract_themes, inputs=theme_input, outputs=theme_output)

demo.launch()