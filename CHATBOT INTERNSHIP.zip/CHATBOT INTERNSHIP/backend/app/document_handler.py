import pytesseract
from PIL import Image
import pdfplumber
import os
import shutil
from fastapi import UploadFile
from uuid import uuid4

async def process_uploaded_file(file: UploadFile):
    doc_id = f"DOC_{uuid4().hex[:6]}"
    temp_path = f"temp_{file.filename}"
    with open(temp_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    if file.filename.endswith(".pdf"):
        with pdfplumber.open(temp_path) as pdf:
            text = "\n".join([page.extract_text() or "" for page in pdf.pages])
    else:
        image = Image.open(temp_path)
        text = pytesseract.image_to_string(image)

    os.remove(temp_path)
    return text, doc_id