from fastapi import FastAPI, UploadFile, File, Form
from app.document_handler import process_uploaded_file
from app.vector_store import add_to_vectorstore, load_vectorstore
from app.query_handler import answer_query, identify_themes

app = FastAPI()
vectorstore = load_vectorstore()

@app.get("/")
def read_root():
    return {"message": "Document Chatbot API is running"}

@app.post("/upload/")
async def upload_document(file: UploadFile = File(...)):
    text, doc_id = await process_uploaded_file(file)
    add_to_vectorstore(text, doc_id)
    return {"message": f"Document {file.filename} processed successfully."}

@app.post("/ask/")
async def ask_question(question: str = Form(...)):
    answer = answer_query(question, vectorstore)
    return {"response": answer}

@app.post("/themes/")
async def extract_themes(question: str = Form(...)):
    themes = identify_themes(question, vectorstore)
    return {"themes": themes}