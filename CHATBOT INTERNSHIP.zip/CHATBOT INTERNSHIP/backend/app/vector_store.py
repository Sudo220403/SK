from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings
import os
from dotenv import load_dotenv

load_dotenv()
embedding = OpenAIEmbeddings()
DB_DIR = "backend/vector_db"

def load_vectorstore():
    os.makedirs(DB_DIR, exist_ok=True)
    return Chroma(persist_directory=DB_DIR, embedding_function=embedding)

def add_to_vectorstore(text, doc_id):
    db = Chroma(persist_directory=DB_DIR, embedding_function=embedding)
    db.add_texts([text], metadatas=[{"doc_id": doc_id}])
    db.persist()