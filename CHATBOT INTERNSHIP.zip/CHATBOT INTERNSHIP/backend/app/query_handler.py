from langchain_openai import OpenAI

llm = OpenAI(temperature=0)

def answer_query(question, vectorstore):
    docs = vectorstore.similarity_search(question, k=4)
    context = "\n".join([doc.page_content for doc in docs])
    prompt = f"Context:\n{context}\n\nQuestion: {question}\nAnswer:"
    response = llm(prompt)
    return response

def identify_themes(question, vectorstore):
    docs = vectorstore.similarity_search(question, k=6)
    context = "\n".join([f"DOC: {doc.metadata.get('doc_id')}\n{doc.page_content}" for doc in docs])
    prompt = f"Based on the following document excerpts, identify common themes and group them clearly:\n\n{context}\n\nThemes:"
    themes = llm(prompt)
    return themes